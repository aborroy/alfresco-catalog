---
title: "Uploader Plus"
description: "Enhances Share uploader with prompts for content type and metadata during upload."
screenshots:
  - "https://opengraph.githubassets.com/1/softwareloop/uploader-plus"
compatibility:
  - "ACS 6.x"
  - "ACS 7.x"
  - "ACS 23.x+"
license: "LGPL-3"
keywords:
  - "share"
  - "uploader"
  - "metadata"
download_url: "https://github.com/softwareloop/uploader-plus"
vendor: "Community"
about: "Enhances Share uploader with prompts for content type and metadata during upload."
about_url: "https://github.com/softwareloop/uploader-plus"
draft: false
---
