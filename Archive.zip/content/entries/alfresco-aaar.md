---
title: "Alfresco Audit Analysis and Reporting (AAAR)"
description: "A.A.A.R. provides dashboards and reports for Alfresco audit data."
screenshots:
  - "https://opengraph.githubassets.com/1/fcorti/alfresco-audit-analysis-reporting"
compatibility:
  - "ACS 6.x"
  - "ACS 7.x"
  - "ACS 23.x+"
license: "Public Domain"
keywords:
  - "auditing"
  - "reporting"
  - "analytics"
  - "share"
download_url: "https://github.com/fcorti/alfresco-audit-analysis-reporting"
vendor: "Francesco Corti"
about: "A.A.A.R. provides dashboards and reports for Alfresco audit data."
about_url: "https://github.com/fcorti/alfresco-audit-analysis-reporting"
draft: false
---
