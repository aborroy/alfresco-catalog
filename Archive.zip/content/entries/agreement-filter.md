---
title: "Agreement Filter"
description: "Displays an agreement/notice to users on first login; they must accept to proceed."
screenshots:
  - "https://opengraph.githubassets.com/1/atolcd/alfresco-agreement-filter"
compatibility:
  - "ACS 6.x"
  - "ACS 7.x"
  - "ACS 23.x+"
license: "LGPL-3"
keywords:
  - "share"
  - "ui"
  - "compliance"
download_url: "https://github.com/atolcd/alfresco-agreement-filter"
vendor: "ATOL Conseils et Développements"
about: "Displays an agreement/notice to users on first login; they must accept to proceed."
about_url: "https://github.com/atolcd/alfresco-agreement-filter"
draft: false
---
