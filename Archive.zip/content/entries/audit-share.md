---
title: "Audit Share"
description: "Adds a Share UI to view Alfresco audit logs with filters and pagination."
screenshots:
  - "https://opengraph.githubassets.com/1/atolcd/alfresco-audit-share"
compatibility:
  - "ACS 6.x"
  - "ACS 7.x"
  - "ACS 23.x+"
license: "LGPL-3"
keywords:
  - "share"
  - "audit"
download_url: "https://github.com/atolcd/alfresco-audit-share"
vendor: "ATOL Conseils et Développements"
about: "Adds a Share UI to view Alfresco audit logs with filters and pagination."
about_url: "https://github.com/atolcd/alfresco-audit-share"
draft: false
---
