---
title: "Alfresco Audit Analysis and Reporting (AAAR)"
description: "Extracts Alfresco audit data into a datamart and ships BI reports/dashboards."
screenshots:
  - "https://opengraph.githubassets.com/1/fcorti/alfresco-audit-analysis-reporting"
compatibility:
  - "ACS 6.x"
  - "ACS 7.x"
  - "ACS 23.x+"
license: "Public Domain"
keywords:
  - "audit"
  - "reporting"
  - "bi"
download_url: "https://github.com/fcorti/alfresco-audit-analysis-reporting"
vendor: "Francesco Corti"
about: "Extracts Alfresco audit data into a datamart and ships BI reports/dashboards."
about_url: "https://github.com/fcorti/alfresco-audit-analysis-reporting"
draft: false
---
