---
title: "Cluster Probe"
description: "Allows removing members from an Alfresco cluster at runtime via a probe endpoint."
screenshots:
  - "https://opengraph.githubassets.com/1/Redpill-Linpro/alfresco-cluster-probe"
compatibility:
  - "ACS 6.x"
  - "ACS 7.x"
  - "ACS 23.x+"
license: "LGPL-3"
keywords:
  - "cluster"
  - "ops"
download_url: "https://github.com/Redpill-Linpro/alfresco-cluster-probe"
vendor: "Redpill Linpro"
about: "Allows removing members from an Alfresco cluster at runtime via a probe endpoint."
about_url: "https://github.com/Redpill-Linpro/alfresco-cluster-probe"
draft: false
---
