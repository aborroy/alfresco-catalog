---
title: "Alfresco CLI"
description: "Command-line interface to navigate and manage Alfresco."
screenshots:
  - "https://opengraph.githubassets.com/1/aborroy/alf-cli"
compatibility:
  - "ACS 6.x"
  - "ACS 7.x"
  - "ACS 23.x+"
license: "Apache-2"
keywords:
  - "cli"
  - "admin"
  - "tools"
download_url: "https://github.com/aborroy/alf-cli"
vendor: "Angel Borroy"
about: "Command-line interface to navigate and manage Alfresco."
about_url: "https://github.com/aborroy/alf-cli"
draft: false
---
