---
title: "Alfresco Audit Dashlet"
description: "Dashlet for viewing Alfresco audit logs directly in Share."
screenshots:
  - "https://opengraph.githubassets.com/1/loftuxab/alfresco-audit-dashlet"
compatibility:
  - "ACS 6.x"
  - "ACS 7.x"
  - "ACS 23.x+"
license: "Apache-2"
keywords:
  - "auditing"
  - "dashlet"
  - "share"
download_url: "https://github.com/share-extras/audit-dashlet"
vendor: "Loftux AB"
about: "Dashlet for viewing Alfresco audit logs directly in Share."
about_url: "https://github.com/share-extras/audit-dashlet"
draft: false
---
