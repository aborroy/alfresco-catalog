---
title: "Alfresco CLI (alf-cli)"
description: "Opinionated CLI to scaffold a ready‑to‑run Docker Compose stack for ACS."
screenshots:
  - "https://opengraph.githubassets.com/1/aborroy/alf-cli"
compatibility:
  - "ACS 6.x"
  - "ACS 7.x"
  - "ACS 23.x+"
license: "Apache-2"
keywords:
  - "devtools"
  - "ops"
download_url: "https://github.com/aborroy/alf-cli"
vendor: "Angel Borroy"
about: "Opinionated CLI to scaffold a ready‑to‑run Docker Compose stack for ACS."
about_url: "https://github.com/aborroy/alf-cli"
draft: false
---
