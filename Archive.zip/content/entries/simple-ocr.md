---
title: "Simple OCR Action"
description: "Adds an action that extracts text from images and PDFs using system OCR tools."
screenshots:
  - "https://opengraph.githubassets.com/1/keensoft/alfresco-simple-ocr"
compatibility:
  - "ACS 6.x"
  - "ACS 7.x"
  - "ACS 23.x+"
license: "LGPL-3"
keywords:
  - "ocr"
  - "transforms"
download_url: "https://github.com/keensoft/alfresco-simple-ocr"
vendor: "keensoft"
about: "Adds an action that extracts text from images and PDFs using system OCR tools."
about_url: "https://github.com/keensoft/alfresco-simple-ocr"
draft: false
---
